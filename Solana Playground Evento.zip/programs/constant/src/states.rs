use anchor_lang::prelude::*;

#[account]
// #[derive(Default)]
pub struct UserProfile {
    pub authority: Pubkey,
    pub last_event: u8,
    pub own_event_count: u8,
    pub entered_event_count: u8,
}

#[account]
// #[derive(Default)]
pub struct EventAccount {
    pub authority: Pubkey,
    pub idx: u8,
    pub title: String,
    pub content: String,
    pub number_entered: bool,
    pub event_fee: u8,
}
