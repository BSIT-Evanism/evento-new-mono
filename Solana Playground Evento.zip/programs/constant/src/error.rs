use anchor_lang::prelude::*;

#[error_code]
pub enum EventError {
    #[msg("You are not Authorized")]
    Unauthorized,
    #[msg("Not Allowed")]
    NotAllowed,
    #[msg("Math operation overflow")]
    MathOverflow,
    #[msg("Already entered")]
    AlreadyEntered,
}
